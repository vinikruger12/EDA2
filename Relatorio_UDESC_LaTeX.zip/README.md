# Relatório TEG - Base Iris (UDESC/CCT)

Este projeto LaTeX contém o relatório da Tarefa 1_A de Teoria dos Grafos,
seguindo a classe `abntex2` e as configurações de apresentação da UDESC
(12 pt, A4, margens esquerda/superior de 3 cm, direita/inferior de 2 cm,
espaçamento de 1,5 linhas e página numerada no canto superior direito).

## Como compilar

No Overleaf: envie o arquivo ZIP como um projeto e compile `main.tex`
com **pdfLaTeX**.

No Linux com TeX Live e abnTeX2:

```bash
latexmk -pdf main.tex
```

## Organização

- `main.tex`: arquivo principal segundo a organização do modelo UDESC.
- `PacotesBasicos.tex`: pacotes, margens, estilos e fonte.
- `PreTextuais/Capa.tex`: capa.
- `Textuais/Capitulo01.tex`: corpo do relatório, tabelas e referências.
- `figuras/`: imagens do grafo geradas pelo script Python da entrega.

A ficha catalográfica, a folha de aprovação e outros elementos de teses e
dissertações foram omitidos por não fazerem parte do relatório original.
